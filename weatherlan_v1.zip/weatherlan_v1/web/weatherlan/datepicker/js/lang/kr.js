var fdLocale = {
/* Uncomment the following line if the first day of the week does not start on Monday */
//firstDayOfWeek:0,
fullMonths:["1\uC6D4", "2\uC6D4", "3\uC6D4", "4\uC6D4", "5\uC6D4", "6\uC6D4", "7\uC6D4", "8\uC6D4", "9\uC6D4", "10\uC6D4", "11\uC6D4", "12\uC6D4"],
monthAbbrs:["1\uC6D4", "2\uC6D4", "3\uC6D4", "4\uC6D4", "5\uC6D4", "6\uC6D4", "7\uC6D4", "8\uC6D4", "9\uC6D4", "10\uC6D4", "11\uC6D4", "12\uC6D4"],
fullDays:["\uC6D4\uC694\uC77C", "\uD654\uC694\uC77C", "\uC218\uC694\uC77C", "\uBAA9\uC694\uC77C", "\uAE08\uC694\uC77C", "\uD1A0\uC694\uC77C", "\uC77C\uC694\uC77C"],
dayAbbrs:["\uC6D4", "\uD654", "\uC218", "\uBAA9", "\uAE08", "\uD1A0", "\uC77C"],
titles:["\uC9C0\uB09C \uB2EC", "\uB2E4\uC74C \uB2EC", "\uC9C0\uB09C \uC8FC", "\uB2E4\uC74C \uC8FC", "\uC624\uB298", "\uB2EC\uB825 \uBCF4\uAE30", "\uC8FC", "[[%1%]]\uC8FC\uC911 [[%0%]]\uC8FC\uCC28", "\uC8FC", "\uB0A0\uC9DC \uC120\uD0DD", "\uB04C\uC5B4\uC11C \uC62E\uAE30\uAE30", "\u0022[[%0%]]\u0022 \uC6B0\uC120\uD45C\uC2DC", "\uC624\uB298\uB0A0\uC9DC\uB85C", "\uC120\uD0DD\uBD88\uAC00 \uB0A0\uC9DC"]};$
try { datePickerController.loadLanguage(); } catch(err) {}

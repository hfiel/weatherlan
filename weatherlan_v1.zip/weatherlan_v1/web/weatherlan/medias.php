﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: index.php
//Version: 3 (version final)
//Descripcion: 
//Muestra datos medios del sensor de temperatura y humedad
//mediante gráfico con flash, generado de
//forma dinamica con open flash chart
//
//AVISO:
//NO HACE GESTION DE ERRORES O VALIDACIÓN, NI PARA DATOS RECIBIDOS NI PARA CONSULTAS SQL
//¡¡¡ESTO PUEDE SER PELIGROSO: PUEDE HACER AL SERVIDOR VULNERABLE A INYECCIONES SQL!!!
//El código no tiene forma de saber si los datos que recibe por get son de Arduino
//o de cualquier otra fuente. Es muy sencillo falsear registros.
//
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

//incluimos codigo para mostrar web de medias
//incluyendo formulario de seleccion
 include_once "content/graf_ardm.php";


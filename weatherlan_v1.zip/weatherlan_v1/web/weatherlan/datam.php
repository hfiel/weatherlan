<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: datam.php
//Version: 3 (version final)
//Descripcion: genera los datos JSON para crear los graficos de minimos, medias, maximos
//mediante OFC, a partir del sensor seleccionado y la fecha indicada
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

//incluimos la libreria de OFC
include 'php-ofc-library/open-flash-chart.php';

//si tenemos fecha y sensor seleccionados, los almacenamos. En caso contrario, paramos la ejecucion
if (isset($_GET['fecha']) and isset($_GET['ip']))
{
	$fecha=$_GET['fecha'];
	$ip=$_GET['ip'];
}
else
{
die();
}
//fichero de configuracion con los datos de BBDD y zona horaria
require_once "content/config.php";


//conectamos a la BBDD 
mysql_connect ($servidor, $usuario, $clave);
mysql_select_db ($bbdd);

//consulta para medias, minimos, maximos
//usamos la funciones de minimo(MIN), maximo(MAX) y media(AVG) de MySQL.
//Para la seleccion de los datos, dado que fecha y hora se almacenan en UTC, primero los pasamos al horario de Europe/Madrid
//usando la funcion CONVERT_TZ. Del campo de fecha, solo usamos la fecha, y no la hora, por lo que convertimos el valor mediante
//la funcion DATE
$consultamedias="SELECT MIN(t1) as mint1,MIN(t2) as mint2,MIN(h1) as minh1, AVG(t1) AS medt1,AVG(t2) AS medt2,AVG(h1) AS medh1,MAX(t1) as maxt1,MAX(t2) as maxt2,MAX(h1) as maxh1 FROM medidas where ip='".$ip."' and DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."'))='".$fecha."'";

//leemos los datos
$resultado = mysql_query ($consultamedias);

//si no tenemos respuesta de la consulta terminamos la ejecucion mostrando el error
if (!resultado) {
	die('Consulta fallida: ' . mysql_error());
}

//volcamos los datos en una fila (recordar que al sacar estos valores medios agrupados, solo recibimos
//como maximo una fila de resultados y no un array
$fila=mysql_fetch_array($resultado);

//variables para poner el maximo y minimo en el eje Y
$maximo=MAX($fila);
$minimo=MIN($fila);

//calculamos cuantos resultados tenemos (como mucho ser� 1)
$cuantos=mysql_num_rows($resultado);

//variables para almacenar los datos de cada sensor
$datos_t1=array();
$datos_t2=array();
$datos_h1=array();

//variable para la etiqueta del eje X
$etiqx=array();



//si he recibido datos
if ($cuantos != 0)
{
	//incluyo 3 elementos en el eje x: minimos, medios, maximos
	$label[]="Minimos";
	$label[]="Medios";
	$label[]="Maximos";
	
	//valores de los sensores en la BBDD, redondeamos a dos decimales
	//valores de t1
		$d = new hollow_dot(round($fila['mint1'],2));
		$datos_t1[]=$d->size(3)->colour('#D02020')->tooltip( 'T1 - #val# &#xB0;C' );
		$d = new hollow_dot(round($fila['medt1'],2));
		$datos_t1[]=$d->size(3)->colour('#D02020')->tooltip( 'T1 - #val# &#xB0;C' );
		$d = new hollow_dot(round($fila['maxt1'],2));
		$datos_t1[]=$d->size(3)->colour('#D02020')->tooltip( 'T1 - #val# &#xB0;C' );

	//valores de t2
		$d = new hollow_dot(round($fila['mint2'],2));
		$datos_t2[]=$d->size(3)->colour('#D02020')->tooltip( 'T2 - #val# &#xB0;C' );
		$d = new hollow_dot(round($fila['medt2'],2));
		$datos_t2[]=$d->size(3)->colour('#D02020')->tooltip( 'T2 - #val# &#xB0;C' );
		$d = new hollow_dot(round($fila['maxt2'],2));
		$datos_t2[]=$d->size(3)->colour('#D02020')->tooltip( 'T2 - #val# &#xB0;C' );

	//valores de h1
		$d = new hollow_dot(round($fila['minh1'],2));
		$datos_h1[]=$d->size(3)->colour('#D02020')->tooltip( 'H1 - #val# &#37;HR' );
		$d = new hollow_dot(round($fila['medh1'],2));
		$datos_h1[]=$d->size(3)->colour('#D02020')->tooltip( 'H1 - #val# &#37;HR' );
		$d = new hollow_dot(round($fila['maxh1'],2));
		$datos_h1[]=$d->size(3)->colour('#D02020')->tooltip( 'H1 - #val# &#37;HR' );
}

//creamos el objeto chart
$chart = new open_flash_chart();
//si tengo datos, le pongo el titulo con la informacion del sensor y la fecha
if ($cuantos != 0)
{
$titulo="Valores medios del sensor ".$ip." el ".$fecha;
}
else //pongo como titulo que no hay datos
{
$titulo="No hay datos para la fecha seleccionada";
}
//establecemos el titulo en el objeto chart
$chart->set_title( new title ($titulo));

//definimos el nuevo elemento linea y asignamos los valores
//del formato (color de cada linea y leyenda asociada)
if ($cuantos != 0)
{
$linea_t1 = new line();
$linea_t1->set_values( $datos_t1);
$linea_t1->set_colour('#FF0000'); //rojo
$linea_t1->set_key( "Temperatura Sensor 1", 10 );
$linea_t2 = new line();
$linea_t2->set_values($datos_t2);
$linea_t2->set_colour( '#347235' ); //verde
$linea_t2->set_key( "Temperatura Sensor 2", 10 );
$linea_h1 = new line();
$linea_h1->set_values($datos_h1);
$linea_h1->set_colour( '#0000FF' ); //azul
$linea_h1->set_key( "Humedad Sensor 1", 10 );
}
//eje X, etiquetas y lineas divisorias
$x_labels = new x_axis_labels();
$x_labels->set_labels( $label );
$x_axis = new x_axis();
$x_axis->set_labels($x_labels);

$x_labels->set_steps(1);
$x_axis->set_steps(1);

//si tengo datos metemos las lineas en el grafico:
if ($cuantos != 0)
{
$chart->add_element( $linea_t1 );
$chart->add_element( $linea_t2 );
$chart->add_element( $linea_h1 );
}
//definimos eje y, con el rango de datos maximo y minimo calculado
$y_axis = new y_axis();
$y_axis->set_range( round($minimo) -5, round($maximo) +5, 5 );

//leyenda del eje Y
$y_legend = new y_legend( 'Temperatura (&#xB0;C)                        Humedad (&#37;HR)' );
$y_legend->set_style( '{font-size: 15px; color: #000000}' );
$chart->set_y_legend( $y_legend );


//incluimos ejes en el grafico
$chart->add_y_axis( $y_axis );
$chart->set_x_axis( $x_axis );

//imprimios los datos del objeto chart (produce datos JSON)
echo $chart->toPrettyString();

?>

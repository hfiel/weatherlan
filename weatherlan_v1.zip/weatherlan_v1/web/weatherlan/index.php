﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: index.php
//Version: 3
//Descripcion: 
//Registra y muestra datos del sensor de temperatura y humedad.
//
//Almacena los datos en MySql y los muestra en gráfico con flash, generado de
//forma dinamica con OFC (Open Flash Chart http://teethgrinder.co.uk/open-flash-chart-2/)
//Recibe los datos por get directamente desde el propio Arduino
//
//Para usar con el código arduino: sensor_3.pde
//
//AVISO:
//NO HACE GESTION DE ERRORES O VALIDACIÓN, NI PARA DATOS RECIBIDOS NI PARA CONSULTAS SQL
//¡¡¡ESTO PUEDE SER PELIGROSO: PUEDE HACER AL SERVIDOR VULNERABLE A INYECCIONES SQL!!!
//El código no tiene forma de saber si los datos que recibe por get son de Arduino
//o de cualquier otra fuente. Es muy sencillo falsear registros.
//
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

require_once "content/config.php";

//encabezado HTML y gestion de carga de jscript (OFC)
include_once "content/encabezado.php";

//gestion del registro de nuevos
//datos procedentes de arduino
if (isset($_GET["reg"]))
{
 //incluimos el fichero con el codigo para almacenar en bbdd
 include_once "content/reg_ard.php";
}
else
{
//incluimos codigo para mostrar web de registros
//incluyendo formulario de seleccion
 include_once "content/graf_ard.php";
}
?>

﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: gestion.php
//Version: 3 (version final)
//Descripcion: gestion de nombres de sensores en la BBDD
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

//incluimos el fichero de configuracion
//con los datos de BBDD y zona horaria
require_once "content/config.php";

//connect to the database 
mysql_connect ($servidor, $usuario, $clave);
mysql_select_db ($bbdd);
//sacamos las IP
$resultadoip = mysql_query ("SELECT DISTINCT sensores.id, medidas.ip,nombre, tz FROM medidas LEFT JOIN sensores ON medidas.ip=sensores.ip ORDER BY medidas.ip");

//si no hay datos de sensores, mostramos mensaje y paramos
if(mysql_num_rows($resultadoip)==0){
	echo "</head>";
	echo "<body>";
	echo "No hay datos de sensores en la BBDD<br/>";
	echo "</body>";
	echo "</html>";
	die();
}

//almacenamos los datos en un array
while($row = mysql_fetch_array($resultadoip))
{
 $arraydatos[]=$row;
}

//cabecera de la web y comienzo del html
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen"/>
<title>WeatherLAN - Configuración</title>
</head>
 
<body>
 
 
<?php
include_once "content/titulo.php";
?>
 

<h3>Gestion de configuración</h3><br/>

<?php

//si hemos recibido nuevo nombre para un sensor
if (isset($_POST['actualizar']) and isset($_POST['sensor']) and (isset($_POST['nuevonombre'])OR isset($_POST['TIMEZONE'])))
{

	//si la identificacion del sensor es solo un numero, ya existia (hemos recibido el id de la fila en la BBDD)
	//y actualizamos el nombre en la BBDD
	if (is_numeric($_POST['sensor']))
	{
		$consultasql="UPDATE sensores SET ";
		if (isset($_POST['nuevonombre']))
		{
			$consultasql.="nombre='".$_POST['nuevonombre']."'";
		}
		if (isset($_POST['nuevonombre']) AND isset($_POST['TIMEZONE']))
		{
			$consultasql.=", ";
		}
		if (isset($_POST['TIMEZONE']))
		{
			$consultasql.="tz='".$_POST['TIMEZONE']."'";
		}
		$consultasql.=" WHERE id='".$_POST['sensor']."' LIMIT 1;";
			if ($debug==1)
			{
				echo $consultasql;
			}
	}
	else//si la identificacion no es numero (hemos recibido su direccion IP), no existia el registro, lo insertamos
	{	
		if (isset($_POST['TIMEZONE']))
		{
			$tz=$_POST['TIMEZONE'];
		}
		else
		{
			$tz="Europe/Madrid";
		}
		$consultasql="INSERT INTO sensores (nombre,ip,tz)  VALUES ('".$_POST['nuevonombre']."','".$_POST['sensor']."', '".$tz."');";
	}
	if ($debug==1)
	{
		echo $consultasql;
	}
	$result = mysql_query($consultasql);
	echo "<br/><b>Nombre actualizado. </b><br/><a href=''>Volver a la configuración</a>";
	die();
}


//si ya tenemos seleccionado un sensor para editar mostramos el formulario para poner el nombre
//El campo contiene el nombre asignado actualmente al sensor o la direccion IP si no tiene nombre asociado
if (isset($_POST['seleccionar']) and isset($_POST['sensor']))
{
	echo "<div id=\"configuracionsensor\">";
	echo "<h4>Datos del sensor</h4> <br/>\n";

?>

<form action="" method="post" enctype="multipart/form-data">
	<input type="hidden" name="sensor" value="<?php echo $_POST["sensor"];?>" />
	Nombre del sensor: <input type="text" name="nuevonombre" /></br>
	Zona horaria:
	<select id="TIMEZONE" name="TIMEZONE">
    <?php
    $timezone_identifiers = DateTimeZone::listIdentifiers();
    foreach( $timezone_identifiers as $value ){
        if ( preg_match( '/^(America|Antartica|Arctic|Asia|Atlantic|Europe|Indian|Pacific)\//', $value ) ){
            $ex=explode("/",$value);//obtain continent,city   
            if ($continent!=$ex[0]){
                if ($continent!="") echo '</optgroup>';
                echo '<optgroup label="'.$ex[0].'">';
            }
   
            $city=$ex[1];
            $continent=$ex[0];
			if ($value==$zonahoraria)
			{
			     echo '<option value="'.$value.'" selected="selected">'.$city.'</option>';
			}
			else
			{
				echo '<option value="'.$value.'">'.$city.'</option>';
			}
?>

<?php
        }
    }
    ?>
        </optgroup>
    </select>
	<input type="submit" name="actualizar" value="Actualizar" />
</form>
</div>



<?php
}
else //No hemos recibido nada aun, mostramos un formulario con la lista de sensores para elegir uno
{
?>
<div id="listasensores">
Seleccione el sensor a editar:
<form action="" method="post" enctype="multipart/form-data">
	<table border=1>
		<tr>
			<th>IP</th>
			<th>Nombre</th>
			<th>Zona horaria</th>
			<th>Editar</th>
		</tr>
<?php
	foreach($arraydatos as $numcol => $row)
	{
		//si tenemos el nombre del registro dado de alta, lo mostramos.
		//En caso contrario, mostramos su ip
		if ($row['nombre']=="")
		{
			$nombre_sensor=$row['ip'];
		}
		else
		{
			$nombre_sensor=$row['nombre'];
		}
		//si el sensor tiene identificador (ya existe en la tabla sensores)
		//lo identificamos con su id
		if ($row['id']=="")
		{
			$identificador=$row['ip'];
		}
		else //no tiene identificador, lo identificamos con su direccion IP
		{
			$identificador=$row['id'];
		}
		echo "<tr><td>".$row['ip']."</td><td>".$nombre_sensor."</td><td>".$row['tz']."</td><td><input type='radio' name='sensor' value='".$identificador."' /></td></tr>\n";
	}
?>

	</table>
<input type="submit" name="seleccionar" value="Seleccionar" />
<?php
}
//cerramos el formulario de gestion de nombres
?>
</form>
</div>
</body>
</html>


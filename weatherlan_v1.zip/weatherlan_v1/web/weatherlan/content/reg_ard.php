﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: reg_ard.php
//Version: 4
//Descripcion: registra los datos recibidos desde arduino en la BBDD MySQL
//
//Cuando se recibe desde arduino una peticion GET de la forma:
//http:\\IP\index.php?reg=1&t1=14.1&t2=14.2&h1=50.5&hora=12&minuto=25&dia=28&mes=5&anyo=2010
//(Siendo IP el servidor donde esta funcionado esta página)
//se procesan los datos y se almacenan en MySql, añadiendo
//a los campos recibidos la IP de origen de la petición ET, así
//como la fecha y hora de la rececpción de los datosl
//si se omite un parametro, se registra en la BBD como NULL
//
//Los campos son:
//reg: este campo se usa para que la temp.php sepa que tiene que registrar un nuevo dato
//t1 y t2: sensores de temperatura 1 (en la placa) y 2 (por cable)
//h1: sensor de humedad 1
//hora, minuto, dia, mes anyo: para almacenar la hora y fecha de la toma de datos, con la
//sincronizacion que obtiene el propio arduino mediante protocolo NTP en formato UTC.
// 
//OJO: la fecha y hora se almacenan en la BBDD en un unico campo de tipo DATETIME
//el formato correcto para alamacenar datos en este campo es "AAAA/MM/DD HH:MM:SS"
//respetando el nº de caracteres de cada elemento y el espacio separando
//los valores separados de fecha y hora se extraen de la bbdd mediante funciones
//de mysql cuando son necesarios

//La BBDD (que tiene que existir previamente) se puede generar mediante PHPMyAdmin 
//usando el fichero sql_sensor_3.sql
//Esta bbdd esta pensada para MySql 5 superior, y necesita que este habilitado el soporte para
//timezone (normalmente es así, pero deberías comprobarlo antes) dado que lo necesita para
//convertir los datos de fecha y hora UTC a la hora local.

//********************************MUY IMPORTANTE*******************************
//*****¿Por qué no uso las funciones de fecha y hora del propio PHP?*****
//Durante el desarrollo guardaba la fecha y hora con funciones de PHP y MySql,
//usando la hora del sistema, pero comprobé que, a pesar de tener correctamente sincronizado
//el reloj de mi equipo con el mismo servidor NTP que arduino, los datos que se obtenian de
//las funciones en PHP o MySql estaban bastante retrasados (hablamos de más de 20 segundos)
//con respecto a la hora del sistema. Esto arruinaba el almacenamiento y procesado de los
//datos. Tras varias búsquedas de soluciones en internet, opté por usar los datos del propio
//arduino, lo que presenta varias ventajas:
// 1- El arduino siempre mantiene la sincronia con el NTP (de hecho, si no puede sincronizar
//    al principio, asume la hora 0 UTC (00:00:00 1/1/1970) de forma automatica y transparente
// 2- Se elimina la necesidad de tener el servidor de almacenamiento sincronizado
// 3- Arduino usa la hora UTC, no hay que jugar con horarios de verano en el almacenamiento
//    (pero hay que tenerlo en cuenta a la hora de procesar y mostrar los datos)
// 4- En casos donde el servidor esté saturado y tarde en procesar las peticiones, se sige
//    almacenando la hora exacta de la medicion, y no la hora del procesamiento del registro
//
//*****¿Por qué uso la hora UTC?*****
//Si usamos la hora UTC no se producen cambios de hora por horario de verano
//esto permite que los registros de fecha/hora sean siempre unicos y facilita la gestion de
//las fechas en las consultas con la BBDD, ademas de evitar problemas con los datos en aquellos
//dias cuando se produce el cambio de hora. PE, en el cambio a horario de invierno, 
//si la hora cambia de las 3:00 AM a las 2:00 AM, tendríamos duplicados todos los registros 
//que se produzcan desde las 2: primero tendríamos registros a las 2:00, 2:05...2:55
//y cuando se produjera el cambio, volveriamos a tener registros a las 2:00, 2:05...2:55
//con el problema que supondria para ordenar los resultados
//Usando UTC y aprovechando las funciones de conversion de fecha y hora de MySQL solucionamos
//estos problemas.
//
//
//*****ES OBLIGATORIO QUE MYSQL TENGA CORRECTAMENTE DEFINIDAS LAS TIMEZONE*****
//En la BBDD mysql del servidor tienen que existir las tablas correspondientes a los timezone.
//Ver el manual de configuracion del servidor para información al respecto
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////



//si recibimos el campo GET reg=1, estamos recibiendo un nuevo registro desde arduino
	if ($_GET["reg"]=="1")
	{
		//incluimos el fichero de configuracion
		//con los datos de BBDD y zona horaria
		require_once "config.php";
		//conexion al servidor bbdd
		$link = mysql_connect($servidor, $usuario, $clave);
		
		/////////////////////////
		//***********************
		//Añadir: comprobacion conexion OK
		//***********************
		/////////////////////////

		//genero la cadena SQL para hacer la introduccion de datos
		//comenzamos con la instruccion insert y la tabla a usar, poniendo ya el campo ip
		$sql = "INSERT INTO ".$tabla." (ip, ";
		//variable para incluir los valores de los campos existentes
		$valores_sql ="";
		//el resto de campos los incluimos en el insert si estan definidos
		//si no lo estan, los datos se registraran en la BBDD como NULL (de forma automatica)
		
		//Incluyo la direccion IP (siempre)
		$valores_sql .= "'".$_SERVER['REMOTE_ADDR']."', ";
		
		//si tengo temperatura 1
		if (isset($_GET["t1"]))
		{
		 //incluyo el campo en la cadena sql
		 $sql .= "t1, ";
		 //incluyo el valor de la variable en valores_sql
		 $valores_sql .= "'".$_GET["t1"]."', ";
		}
		//si tengo temperatura 2
		if (isset($_GET["t2"]))
		{
		 $sql .= "t2, ";
		 $valores_sql .= "'".$_GET["t2"]."', ";
		}
		//si tengo humedad 1
		if (isset($_GET["h1"]))
		{
		 $sql .= "h1, ";
		 $valores_sql .= "'".$_GET["h1"]."', ";
		}
		
		//incluyo la fecha y hora (siempre, no se admiten valores nulos) y termino la parte de definicion de campos
		//y abro la parte de valores, para concatenar despues ambas cadenas sql y valores_sql
		//en caso de que no se pusiera la fecha, la BBDD la pone como defecto en 0000-00-00 00:00:00
		$sql .= "fechahora) VALUES ("; 
		
		//valores para la fecha
		//depende de si recibo datos de arduino (uso los datos recibidos: bueno)
		//o si no recibo (uso la hora del sistema: peor)
		
		//si tengo dia, mes, anyo, hora, minuto, los incluyo
		if (isset($_GET["dia"]) and isset($_GET["mes"]) and isset($_GET["anyo"]) and isset($_GET["hora"]) and isset($_GET["minuto"]))
		{
		 //en MYSQL, la fecha es de la forma YYYY-MM-DD y la hora de la forma  HH:MM:SS
		 //es necesario poner todos los campos para evitar que MySql asuma valores
		 //puede ponerse cualquier caracter como separador, pero vamos a usar / y :
		 //los segundos los ponemos siempre como 00 para facilitar las consultas
		 //(el sensor arduino envia los datos siempre en segundo 00, pero es posible que haya retrasos
		 //en la transmision y la escritura se produzca en 01 ó 02)
		 //
		 //	OJO: recordar que hay que usar hora UTC (ver explicacion al comienzo del fichero)
		 //
		 $valores_sql .= "'".$_GET["anyo"]."/".$_GET["mes"]."/".$_GET["dia"]." ".$_GET["hora"].":".$_GET["minuto"].":00'";
		}
		else //si no he recibido datos desde arduino, pongo la actual del sistema
		{
		//añado la fecha y la hora, teniendo en cuenta el formato UTC
		//
		//para la hora, la saco mediante PHP (horas y minutos) y le añado los segundos como ":00"
		//la funcion gmdate() en php: entrega fechas en formato UTC
			//H hora en formato 24 con ceros
			//i minutos con ceros
			//gmdate("H:i");
			//y detras le añado los segundos
			//":00";
		 //para la fecha, vuelvo a usar gmdate() por el tema de UTC, esta vez con
			// Y: año 4 digitos
			// m: mes dos digitos, con ceros
			// d: dia dos digitos, con ceros
			//Los caracteres de separacion (/) hay que escaparlos con \\ para que se muestren 
			//gmdate("Y\\/m\\/d");
		 $valores_sql .= "'".gmdate("Y\\/m\\/d")." ".gmdate("H:i").":00'";
		}
		
		//concateno ambas cadenas y cierro la consulta con el paréntesis
		$sql .= $valores_sql.")";
		 
		//ya tenemos la cadena completa construida correctamente
		
		//DEBUG: muestro la cadena:
		//NO DEBUG: guardo en BBDD
		if ($debug==1)
		{
			//muestro en pantalla
			echo $sql;
		}
		else
		{
			//Guardo datos
			//conectamos a la tabla sensor
			mysql_select_db($bbdd, $link);
			//lanzo la cadena al servidor MySQL
			$result = mysql_query($sql);
			
			/////////////////////////
			//***********************
			//FALTA Añadir: comprobacion escritura OK
			//***********************
			/////////////////////////		
		}
	}
	else //si el parametro GET['reg'] recibido no es correcto, no hacemos registro (se ha hecho una peticion no valida)
	{
		echo "Error al solicitar el registro de datos";
	}
?>
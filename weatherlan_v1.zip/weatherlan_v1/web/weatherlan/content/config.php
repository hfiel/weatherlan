﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: config.php
//Version: 3 (version final)
//Descripcion: datos de conexion a la BBDD y zona horaria a usar en la conversion
//de tiempos de UTC a hora local
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

//Variable de almacenamiento de la URL de la web
//incluye comprobacion de HTTP o HTTPS
$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';

//$url .= $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
$url .= $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']);

//datos de conexion a la BBDD
$servidor = "localhost";
$bbdd = "BASE_DE_DATOS";
$usuario = "USUARIO_MYSQL";
$clave = "CLAVE_MYSQL";
//tabla de medidas, no modificar
$tabla = "medidas";

//zona horaria por defecto
//segun el formato estandar timezone
$zonahoraria = "Europe/Madrid";

//MODO depuracion: debug=1
$debug = 0;
?>
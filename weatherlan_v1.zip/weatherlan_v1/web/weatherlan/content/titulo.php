﻿<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
	<h1><a href="#">WeatherLAN  </a></h1>
			</div>
			<div id="menu">
				<ul>
					<li><a href="<?php echo $url;?>/index.php">Datos diarios</a></li>
					<li><a href="<?php echo $url;?>/index.php?g=m">Medias</a></li>
					<li><a href="<?php echo $url;?>/gestion.php">Configuración</a></li>
					<li><a href="<?php echo $url;?>/acerca.php">Acerca de</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
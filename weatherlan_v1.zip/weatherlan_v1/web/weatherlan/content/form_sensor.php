﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: form_sensor.php
//Version: 3 (version final)
//Descripcion: genera el formulario de seleccion de sensor y fecha
//Obtiene los datos de sensor de la BBDD (muestra su nombre si esta definido, o
//la IP en caso contrario).
//Las consultas para las fechas se generan de forma dinamica para mostrar
//solamente aquellas fechas que tengan datos para el sensor seleccionado
//Se realiza mediante campos select que envian los datos mediante POST
//cuando se cambia la seleccion (onChange='submit()')
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////


//cargamos configuracion de conexion a la bbdd
require_once "config.php";

//primero sacamos de la bbdd las ip disponibles y las fechas asociadas a cada una

//conectamos a la BBDD
mysql_connect ($servidor, $usuario, $clave);
mysql_select_db ($bbdd);
//sacamos las IP y el nombre del sensor
//haciendo un LEFT JOIN en las tablas medidas y sensores, para que los sensores que no tengan nombre asignado salgan como IP
$resultadoip = mysql_query ("SELECT DISTINCT medidas.ip,nombre FROM medidas LEFT JOIN sensores ON medidas.ip=sensores.ip ORDER BY medidas.ip");

//si no hay datos, mostramos mensaje y salimos
if(mysql_num_rows($resultadoip)==0){
	echo "</head>";
	echo "<body>";
	echo "No hay datos de sensores en la BBDD<br/>";
	echo "</body>";
	echo "</html>";
	die();
}
//creamos el formulario
?>
<form action="" method="post">
  <label>Sensor:</label>
  <select name="sensor_ip" id="sensorip" onChange="submit()">
  <option value="">Seleccione sensor</option>
<?php
//mientras haya filas de datos recibidas, procesamos
while ($row = mysql_fetch_array($resultadoip))
{
	//si no tenemos el nombre del registro dado de alta, usamos como nombre su su ip
	//si el nombre esta definido, lo usamos tal cual
	if ($row['nombre']=="")
	{
		$nombre_sensor=$row['ip'];
	}
	else
	{
		$nombre_sensor=$row['nombre'];
	}
	//el valor del campo es siempre la IP
	echo "<option value='".$row['ip']."'";
	//si actualmente ya tenemos un sensor seleccionado, lo ponemos
	//como selected para que se mantenga elegido
	if (isset($_POST['sensor_ip']) and ($row['ip']==$_POST['sensor_ip']))
	{
		echo " selected='selected'";
	}
	//mostramos al usuario el nombre del sensor que definimos arriba (ya sea el nombre o la IP)
	echo ">".$nombre_sensor."</option>\n";
}
	echo  "</select>\n";
//Si tenemos un sensor seleccionado, mostramos los años que tienen datos para ese sensor
if ((isset($_POST['sensor_ip']) and $_POST['sensor_ip']!=""))
{
	//lanzamos la consulta limitada al sensor seleccionado
	//El campo de fecha de la bbdd lo convertimos a años, y hacemos
	//la adaptacion del formato UTC que almacena la BBDD a la hora local definida en el fichero de configuracion
	//ordenamos por año
	$sqlanyo="SELECT DISTINCT YEAR(DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."'))) AS anyo FROM medidas where ip='".$_POST['sensor_ip']."' ORDER BY anyo";
	//echo $sqlanyo;
	$resultadoanyo = mysql_query ($sqlanyo);
	
  //creamos el select para los años
  echo "<label>Año:</label>\n";
  echo "<select name='anyo' id='anyo' onChange='submit()'>\n";
  echo "<option value=\"\">Año</option>";
	while ($row = mysql_fetch_array($resultadoanyo))
	{
		echo "<option value='".$row['anyo']."'";
		if (isset($_POST['anyo']) and ($row['anyo']==$_POST['anyo']))
		{
			echo " selected='selected'";
		}
		echo ">".$row['anyo']."</option>\n";
	}
	echo  "</select>";
}
//Si tenemos sensor y años, mostramos meses
if ((isset($_POST['sensor_ip']) and $_POST['sensor_ip']!="") and (isset($_POST['anyo']) and $_POST['anyo']!=""))
{

	//lanzamos la consulta limitada al sensor seleccionado y el año seleccionado
	//El campo de fecha de la bbdd lo convertimos a meses, y hacemos
	//la adaptacion del formato UTC que almacena la BBDD a la hora local definida en el fichero de configuracion
	//ordenamos por meses
	
	$sqlmes="SELECT DISTINCT MONTH(DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."'))) AS mes FROM medidas where ip='".$_POST['sensor_ip']."' AND YEAR(DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."'))) ='".$_POST['anyo']."' ORDER BY mes";
	$resultadomes = mysql_query ($sqlmes);
  
  //creamos el select para los meses
  echo "<label>Mes:</label>\n";
  echo "<select name='mes' id='mes' onChange='submit()'>\n";
  echo "<option value=\"\">Mes</option>";
	while ($row = mysql_fetch_array($resultadomes))
	{
		echo "<option value='".$row['mes']."'";
		if (isset($_POST['mes']) and ($row['mes']==$_POST['mes']))
		{
			echo " selected='selected'";
		}
		echo ">".$row['mes']."</option>\n";
	}
	echo  "</select>";
}
//si tenemos sensor, año y mes, mostramos dias
if ((isset($_POST['sensor_ip']) and $_POST['sensor_ip']!="") and (isset($_POST['anyo']) and $_POST['anyo']!="") and (isset($_POST['mes']) and $_POST['mes']!=""))
{

	//lanzamos la consulta limitada al sensor seleccionado, el año seleccionado y el mes seleccionado
	//El campo de fecha de la bbdd lo convertimos a dias, y hacemos
	//la adaptacion del formato UTC que almacena la BBDD a la hora local definida en el fichero de configuracion
	//ordenamos por dias

	$sqldia="SELECT DISTINCT DAY(DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."'))) AS dia FROM medidas where ip='".$_POST['sensor_ip']."' AND YEAR(DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."'))) ='".$_POST['anyo']."' AND MONTH(DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."')))='".$_POST['mes']."' ORDER BY dia";
	$resultadodia = mysql_query ($sqldia);
  
  //creamos el select para los dias
  echo "<label>Dia:</label>\n";
  echo "<select name='dia' id='dia' onChange='submit()'>\n";
  echo "<option value=\"\">Dia</option>";
	while ($row = mysql_fetch_array($resultadodia))
	{
		echo "<option value='".$row['dia']."'";
		if (isset($_POST['dia']) and ($row['dia']==$_POST['dia']))
		{
			echo " selected='selected'";
		}
		echo ">".$row['dia']."</option>\n";
	}
	echo  "</select>";
}
//cerramos el formulario
?>
</form>
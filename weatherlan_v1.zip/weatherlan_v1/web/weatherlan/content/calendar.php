﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: calendar.php
//Version: 3 (version final)
//Descripcion: 
//Genera el calendario para la seleccion de fechas del sensor
//
// Usa el widget de generacion de calendarios Unobtrusive Date-Picker Widget V5
// URL: http://www.frequency-decoder.com/2009/09/09/unobtrusive-date-picker-widget-v5
// Licencia: CC - BY - SA 3.0
// Autor original: Brian McAllister
//
//
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

//gestion del registro de nuevos
//datos procedentes de arduino


//cargamos configuracion de conexion a la bbdd


if ((isset($_POST['sensor_ip']) and $_POST['sensor_ip']!=""))
{
	$sensorip=$_POST['sensor_ip'];
}

require_once "config.php";
//conectamos a la BBDD
mysql_connect ($servidor, $usuario, $clave);
mysql_select_db ($bbdd);
//creamos el formulario

?>


<form action="" method="post">
  <label>Sensor:</label>
  <select name="sensor_ip" id="sensorip" onChange="submit()">
  <option value="">Seleccione sensor</option>
<?php

$resultadoip = mysql_query ("SELECT DISTINCT medidas.ip,nombre FROM medidas LEFT JOIN sensores ON medidas.ip=sensores.ip ORDER BY medidas.ip");

//mientras haya filas de datos recibidas, procesamos
while ($row = mysql_fetch_array($resultadoip))
{
	//si no tenemos el nombre del registro dado de alta, usamos como nombre su su ip
	//si el nombre esta definido, lo usamos tal cual
	if ($row['nombre']=="")
	{
		$nombre_sensor=$row['ip'];
	}
	else
	{
		$nombre_sensor=$row['nombre'];
	}
	//el valor del campo es siempre la IP
	echo "<option value='".$row['ip']."'";
	//si actualmente ya tenemos un sensor seleccionado, lo ponemos
	//como selected para que se mantenga elegido
	if (isset($_POST['sensor_ip']) and ($row['ip']==$_POST['sensor_ip']))
	{
		echo " selected='selected'";
	}
	//mostramos al usuario el nombre del sensor que definimos arriba (ya sea el nombre o la IP)
	echo ">".$nombre_sensor."</option>\n";
}
	echo  "</select>\n";
	echo "</form>\n";
//cerramos el formulario
if ((isset($_POST['sensor_ip']) and $_POST['sensor_ip']!=""))
{
$resultadofechas = mysql_query("SELECT DISTINCT DATE_FORMAT(CONVERT_TZ(fechahora,'UTC','Europe/Madrid'), '%Y%m%d') AS fechas FROM medidas where ip='".$sensorip."' ORDER BY fechas");

$fechamax = mysql_query("SELECT MAX(DATE_FORMAT(CONVERT_TZ(fechahora,'UTC','Europe/Madrid'), '%Y%m%d')) AS fechamax FROM medidas where ip='".$sensorip."'");
$fechamax_form = mysql_query("SELECT MAX(DATE_FORMAT(CONVERT_TZ(fechahora,'UTC','Europe/Madrid'), '%Y-%m-%d')) AS fechamaxform FROM medidas where ip='".$sensorip."'");
$fechamin = mysql_query("SELECT MIN(DATE_FORMAT(CONVERT_TZ(fechahora,'UTC','Europe/Madrid'), '%Y%m%d')) AS fechamin FROM medidas where ip='".$sensorip."'");

//si no hay datos, mostramos mensaje y salimos
if(mysql_num_rows($resultadofechas)==0){
	echo "</head>";
	echo "<body>";
	echo "No hay datos de sensores en la BBDD<br/>";
	echo "</body>";
	echo "</html>";
}

?>

	<form id="formcalend" method="post" action="")>
	<input type="hidden" name="sensor_ip" value="<?php echo $sensorip;?>"/>
	Fecha: 
	<input type="text" class="w16em" id="formfecha" name="formfecha" value="<?php 
	if (isset($_POST['formfecha']) and $_POST['formfecha']!="")
	{
		echo $_POST['formfecha'];
	}
	else
	{
		echo mysql_result($fechamax_form,0);
	}
?>" />
	
      <script type="text/javascript">
      // <![CDATA[ 
        var opts = {                            
                formElements:{"formfecha":"Y-ds-m-ds-d"},
				<?php
	if (isset($_POST['formfecha']) and $_POST['formfecha']!="")
	{
		echo "staticPos:false,";
	}
	else
	{
		echo "staticPos:true,";
	}
?>				
				statusFormat:"l-cc-sp-d-sp-F-sp-Y",
				rangeLow:"<?php echo mysql_result($fechamin,0);?>",
				rangeHigh:"<?php echo mysql_result($fechamax,0);?>",
				enabledDates:{
<?php
while ($row = mysql_fetch_array($resultadofechas))
{
	$cadenafechas.='"'.$row['fechas'].'":1,';
}
	//elimino el ultimo caracter de la cadena (es una coma)
	//porque el motor jscript de IExplore se para si la cadena no esta terminada
	//correctamente. En firefox va bien
	echo substr_replace($cadenafechas,"",-1);;
?>
				}
                };      
        datePickerController.createDatePicker(opts);
      // ]]>
      </script>
	  <input type="submit" value="Ver datos" />
</form>
<?php
//cerramos el if $POST[sensor_ip]
}
?>

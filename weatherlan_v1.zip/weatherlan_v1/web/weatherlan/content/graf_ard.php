﻿<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//Fichero: graf_ard.php
//Version: 3 (version final)
//Descripcion: genera el codigo HTML para crear la web con los graficos
//en flash generados mediante OFC y permitir guardar como imagen png.
//Esta es la pagina para los graficos de los valores diarios.
//Muestra el formulario de seleccion de sensor y fecha.
//Cuando la pagina recibe todos los datos del formulario de seleccion
//(sensor, año, mes, dia) muestra los graficos
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

//cabecera de la web y funciones javascript
?>
<body>
<noscript>
    <h2>Javascript desactivado. Es necesario activarlo para que la página funcione.</h2>
</noscript>


<?php
include_once "titulo.php";
	if (isset($_GET['g']) and $_GET['g']=="m")
	{
		echo "<h3>Consulta de medias</h3>";
	}
	else
	{
		echo "<h3>Consulta de datos diarios</h3>";
	}
?>

<div id="calendario">
<!--[if IE]>
<strong>Está usando Internet Explorer:</strong> la función de exportar imagen no está disponible.<br/>
<![endif]-->
<?php
//formulario seleccion sensor
include_once "calendar.php";
echo "</div>";


//div para crear las graficas

//Importante: la diferencia entre graficos diarios (data.php)o de medias (datam.php) se define en
//el encabezado, donde se indica el fichero origen de datos al script de OFC. Ver encabezado.php

//Si estamos en internet explorer, muestro el aviso de que no funciona exportar como imagen
?>
<div id='my_chart';"></div>
</body>
</html>
<?php
?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es-es">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>WeatherLAN - Consulta de datos</title>
<meta name="keywords" content="sensor" />
<meta name="description" content="Sensor temperatura y humedad Arduino" />
<!-- DATEPICKER -->
<script type="text/javascript" src="datepicker/js/lang/es.js"></script>
<script type="text/javascript" src="datepicker/js/datepicker.js">{}</script>
<link href="datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen"/>

<?php
//si hemos recibido del formulario el sensor y todos los campos de fecha
//incluimos el codigo javascript para poder generar los graficos con OFC
if ((isset($_POST['sensor_ip']) and $_POST['sensor_ip']!="") and (isset($_POST['formfecha']) and $_POST['formfecha']!=""))
{
	echo "<script src=\"js/jquery-1.4.2.min.js\" type=\"text/javascript\"></script>";
	echo "<script type=\"text/javascript\" src=\"js/swfobject.js\"></script>";
	echo "<script type=\"text/javascript\">";
	$quesensor=$_POST['sensor_ip'];
	$quefecha=$_POST['formfecha'];
	if (isset($_GET['g']) and $_GET['g']=="m")
	{
		$fuentedatos="datam.php";
	}
	else
	{
		$fuentedatos="data.php";
	}
	$urlenlace=urlencode($fuentedatos."?ip=".$quesensor."&fecha=".$quefecha);
	//jscript para que lso graficos OFC se queden en el fondo de la web
	//necesario para que el calendario flotante aparezca delante
	//y no se quede tapado por los graficos
?>
    var flashvars = {};
    var params = {};
    params.wmode = "opaque";
    var attributes = {};
<?php
	echo "swfobject.embedSWF('open-flash-chart.swf', 'my_chart', '800', '600', '9.0.0', 'expressInstall.swf', {'data-file':'";
	echo $urlenlace;
	echo "'}, flashvars, params, attributes);";
	echo "</script>";

	//codigo javascript para permitir guardar como imagen PNG
	//SOLO FUNCIONA EN FIREFOX, INTERNET EXPLORER NO GESTIONA
	//BIEN LOS DATOS RECIBIDOS Y NO ES CAPAZ DE GENERAR EL PNG
?>
		<!-- OFC -->
	<script type="text/javascript">
 
OFC = {};
 
OFC.jquery = {
    name: "jQuery",
    version: function(src) { return $('#'+ src)[0].get_version() },
    rasterize: function (src, dst) { $('#'+ dst).replaceWith(OFC.jquery.image(src)) },
    image: function(src) { return "<img src='data:image/png;base64," + $('#'+src)[0].get_img_binary() + "' />"},
    popup: function(src) {
        var img_win = window.open('', 'Sensor - Guardar como imagen')
        with(img_win.document) {
            write('<html><head><title>Sensor - Guardar como imagen<\/title><\/head><body>' + OFC.jquery.image(src) + '<\/body><\/html>') }
		// cerramos el envio de datos para que no este continuamente mostrando el mensaje de "cargando"
		img_win.document.close();
     }
}
 
// Using an object as namespaces is JS Best Practice. 
if (typeof(Control == "undefined")) {var Control = {OFC: OFC.jquery}}
 
 
//Hacer clic derecho en el grafico y seleccionar "Save image locally" llama a esta funcion
function save_image() { OFC.jquery.popup('my_chart') }
function moo() { alert(99); };
</script>

<?php
}
//codigo html de la web
?>
</head>
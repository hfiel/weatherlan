<?php

class area_line extends area_base
{
	function area_line()
	{
		$this->type      = "area_line";
		parent::area_base();
	}
}

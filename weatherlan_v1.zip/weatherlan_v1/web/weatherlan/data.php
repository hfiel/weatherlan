<?php
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//WeatherLAN: Sensor de temperatura y humedad con arduino
//http://hfiel.es
//
// Copyright 2011 Hector Fiel - contacto@hfiel.es
//
//
// This file is part of WeatherLAN.
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//Fichero: data.php
//Version: 3 (version final)
//Descripcion: genera los datos JSON para crear los graficos de valores diarios
//mediante OFC, a partir del sensor seleccionado y la fecha indicada
//Las consultas SQL a la BBDD incluyen la conversion de hora UTC a hora local, segun la 
//zona horaria definida en el fichero de configuracion
//Cuando se extraen los datos, se comprueba que haya continuidad en los registros
//y no se hayan producido cortes (se debe recibir un dato nuevo cada 5 minutos exactos,
//comenzando a las 00:00 de cada d�a). En caso de detectar dos registros con una separacion
//mayor a 5 minutos, se indica en el titulo y se muestra un simbolo para reflejar el
//corte en la linea del grafico.
//Las divisiones del eje Y (temperatura y humedad) se calculan en funcion de los valores
//maximo y minimo encontrados en los datos
//Las divisiones del eje X (horas) se calculan en funcion del numero de registros recibidos
//para que siempre se pueda leer correctamente la etiqueta de la hora
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////



//si tenemos fecha y sensor seleccionados, los almacenamos.
//En caso contrario, paramos la ejecucion
if (isset($_GET['fecha']) and isset($_GET['ip']))
{
	$fecha=$_GET['fecha'];
	$ip=$_GET['ip'];		
}
else
{
die();
}

//fichero de configuracion con los datos de BBDD y zona horaria
require_once "content/config.php";

//conectamos a la BBDD 
mysql_connect ($servidor, $usuario, $clave);
mysql_select_db ($bbdd);

//incluimos la libreria de OFC
include 'php-ofc-library/open-flash-chart.php';

//consulta con los valores del sensor y la fecha seleccionada
//Para la seleccion de los datos, dado que fecha y hora se almacenan en UTC, primero los pasamos al horario de Europe/Madrid
//usando la funcion CONVERT_TZ. Para sacar los datos de hora convertimos el valor mediante la funcion TIME. 
//Para la seleccion de los datos de la fecha concreta, convertimos mediante la funcion DATE
$consultasql="SELECT t1,t2,h1, TIME(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."')) AS hora FROM medidas where ip='".$ip."' and DATE(CONVERT_TZ(fechahora,'UTC','".$zonahoraria."'))='".$fecha."' ORDER BY hora";

//leemos los datos
$resultado = mysql_query ($consultasql);

//si no tenemos respuesta de la consulta terminamos la ejecucion mostrando el error
if (!$resultado) {
	die('Consulta fallida: ' . mysql_error());
}

//variables para poner el maximo y minimo en el eje Y
//el maximo se inicializa a -1000.0 y el minimo a 1000.0
//para que siempre haya un dato real mayor o menor respectivamente

$maximo=-1000.0;
$minimo=1000.0;

//variable para ver si se han perdido datos
//entre registros, inicializada a las 00:00
//se usa para comprobar que los datos se han recibido cada 5 minutos
$horaanterior="00:00";
$horaactual="00:00";
//convertimos la cadena de texto con la hora anterior al formato tiempo
$horaanteriortime=strtotime($horaanterior);

//variable para indicar que hemos tenido cortes en el registro
$haycorte=0;

//calculamos el numero de resultados
$cuantos=mysql_num_rows($resultado);

//variables para almacenar los datos de cada sensor
$datos_t1=array();
$datos_t2=array();
$datos_h1=array();

//variable para la etiqueta del eje X
$etiqx=array();

//saco los datos de la BBDD en mi propio array
$arraydatos=array();
//mientras tenga datos, proceso cada fila
while($row = mysql_fetch_array($resultado))
{
 $arraydatos[]=$row;
}

//si tengo datos, proceso
if ($cuantos != 0)
{
	//datos del sensor de temperatura 1
	//(incluye las horas del eje x)
	
	//por cada elemento fila
	foreach($arraydatos as $numcol => $row)
	{
		//ponemos el valor de cada punto (temperatura) en el array $val
		$val=floatval($row['t1']);
		//buscamos maximo o minimo
		if ($val<$minimo)
		{
			$minimo=$val;
		}
		if ($val>$maximo)
		{
			$maximo=$val;
		}
		//comprobamos si hemos tenido diferencia de mas de 5 minutos
		$horaactual=date("H:i", (mktime(substr($row['hora'],0,2),substr($row['hora'],3,2),0,substr($fecha,5,2),substr($fecha,8,2),substr($fecha,0,4))));
		$horaactualtime=strtotime($horaactual);
		//obtenemos la diferencia en minutos
		$difertime=($horaactualtime-$horaanteriortime)/60;
		//guardamos la hora actual como anterior, para la siguiente vuelta
		$horaanteriortime=$horaactualtime;
		//si la diferencia es de 5 minutos, creamos la etiqueta de forma normal
		if ($difertime==5 or ($horaactual=="00:00"))
		{
			//ponemos la etiqueta para el eje X en $label
			$label[]=date("H:i", (mktime(substr($row['hora'],0,2),substr($row['hora'],3,2),0,substr($fecha,5,2),substr($fecha,8,2),substr($fecha,0,4))));
			//definimos el punto
			$d = new dot($val);
			///ponemos en el array $datos_t1 los nuevos puntos, como toltip su valor, y con los estilos del punto
			$datos_t1[]=$d->size(3)->colour('#D02020')->tooltip( 'T1 #x_label# - #val# &#xB0;C' );
		}
		//si tenemos una separacion diferente a 5 minutos, destacamos la etiqueta
		if ($difertime!=5  and ($horaactual!="00:00"))
		{
			$haycorte=1;
			$label[]="*".date("H:i", (mktime(substr($row['hora'],0,2),substr($row['hora'],3,2),0,substr($fecha,5,2),substr($fecha,8,2),substr($fecha,0,4))));
			//definimos el punto como estrella
			$d = new bow($val);
			///ponemos en el array $datos_t1 los nuevos puntos, como toltip su valor, y con los estilos del punto
			$datos_t1[]=$d->size(10)->halo_size(2)->colour('#D02020')->tooltip( 'T1 #x_label# - #val# &#xB0;C' );
		}

	}
	//t2
	foreach($arraydatos as $numcol => $row)
	{
		//ponemos el valor de cada punto (temperatura) en el array $val
		$val=floatval($row['t2']);
		//buscamos maximo o minimo
		if ($val<$minimo)
		{
			$minimo=$val;
		}
		if ($val>$maximo)
		{
			$maximo=$val;
		}
		//comprobamos si hemos tenido diferencia de mas de 5 minutos
		$horaactual=date("H:i", (mktime(substr($row['hora'],0,2),substr($row['hora'],3,2),0,substr($fecha,5,2),substr($fecha,8,2),substr($fecha,0,4))));
		$horaactualtime=strtotime($horaactual);
		//obtenemos la diferencia en minutos
		$difertime=($horaactualtime-$horaanteriortime)/60;
		//guardamos la hora actual como anterior, para la siguiente vuelta
		$horaanteriortime=$horaactualtime;
		//si la diferencia es de 5 minutos, creamos la etiqueta de forma normal
		if ($difertime==5 or ($horaactual=="00:00"))
		{
			//definimos el punto
			$d = new dot($val);
			///ponemos en el array $datos_t1 los nuevos puntos, como toltip su valor, y con los estilos del punto
			$datos_t2[]=$d->size(3)->colour('#D02020')->tooltip( 'T2 #x_label# - #val# &#xB0;C' );
		}
		//si tenemos una separacion diferente a 5 minutos, destacamos la etiqueta
		if ($difertime!=5  and ($horaactual!="00:00"))
		{
			$haycorte=1;
			//definimos el punto como estrella
			$d = new bow($val);
			///ponemos en el array $datos_t1 los nuevos puntos, como toltip su valor, y con los estilos del punto
			$datos_t2[]=$d->size(10)->halo_size(2)->colour('#D02020')->tooltip( 'T2 #x_label# - #val# &#xB0;C' );
		}
	}
	//h1
	foreach($arraydatos as $numcol => $row)
	{
		//ponemos el valor de cada punto (temperatura) en el array $val
		$val=floatval($row['h1']);
		//buscamos maximo o minimo
		if ($val<$minimo)
		{
			$minimo=$val;
		}
		if ($val>$maximo)
		{
			$maximo=$val;
		}
		//comprobamos si hemos tenido diferencia de mas de 5 minutos
		$horaactual=date("H:i", (mktime(substr($row['hora'],0,2),substr($row['hora'],3,2),0,substr($fecha,5,2),substr($fecha,8,2),substr($fecha,0,4))));
		$horaactualtime=strtotime($horaactual);
		//obtenemos la diferencia en minutos
		$difertime=($horaactualtime-$horaanteriortime)/60;
		//guardamos la hora actual como anterior, para la siguiente vuelta
		$horaanteriortime=$horaactualtime;
		//si la diferencia es de 5 minutos, creamos la etiqueta de forma normal
		if ($difertime==5 or ($horaactual=="00:00"))
		{
			//definimos el punto
			$d = new dot($val);
			///ponemos en el array $datos_t1 los nuevos puntos, como toltip su valor, y con los estilos del punto
			$datos_h1[]=$d->size(3)->colour('#D02020')->tooltip( 'H1 #x_label# - #val# &#37;HR' );
		}
		//si tenemos una separacion diferente a 5 minutos, destacamos la etiqueta
		if ($difertime!=5  and ($horaactual!="00:00"))
		{
			$haycorte=1;
			//definimos el punto como estrella
			$d = new bow($val);
			///ponemos en el array $datos_t1 los nuevos puntos, como toltip su valor, y con los estilos del punto
			$datos_h1[]=$d->size(10)->halo_size(2)->colour('#D02020')->tooltip( 'H1 #x_label# - #val# &#37;HR' );
		}
	}
}


$chart = new open_flash_chart();
if ($cuantos != 0)
{
	if ($haycorte==0)
	{
		$titulo="Temperaturas del sensor ".$ip." el ".$fecha." (".$cuantos." registros)";
	}
	else
	{
		$titulo="Temperaturas del sensor ".$ip." el ".$fecha." (".$cuantos." registros) AVISO: CORTES EN EL REGISTRO";
	}
}
else
{
$titulo="No hay datos para la fecha seleccionada";
}
if ($haycorte==0)
{
	$chart->set_title( new title ($titulo));
}
else
{
	$charttitulo=new title ($titulo);
	$charttitulo->set_style("{font-size: 15px; color: #DF0101}");
	$chart->set_title( $charttitulo);
}

//definimos el nuevo elemento linea y asignamos los valores
if ($cuantos != 0)
{
$linea_t1 = new line();
$linea_t1->set_values( $datos_t1);
$linea_t1->set_colour('#FF0000'); //rojo
$linea_t1->set_key( "Temperatura Sensor 1", 10 );
$linea_t2 = new line();
$linea_t2->set_values($datos_t2);
$linea_t2->set_colour( '#347235' ); //verde
$linea_t2->set_key( "Temperatura Sensor 2", 10 );
$linea_h1 = new line();
$linea_h1->set_values($datos_h1);
$linea_h1->set_colour( '#0000FF' ); //azul
$linea_h1->set_key( "Humedad Sensor 1", 10 );
}
//eje X
$x_labels = new x_axis_labels();
$x_labels->set_labels( $label );
$x_axis = new x_axis();
$x_axis->set_labels($x_labels);

switch ($cuantos)
{
 case ($cuantos <= 30):
  $x_labels->set_steps(3);
  $x_axis->set_steps(1);
  break;
 case ($cuantos <= 80):
 $x_labels->set_steps(6);
 $x_axis->set_steps(3);
  break;
 case ($cuantos <= 140):
 $x_labels->set_steps(10);
 $x_axis->set_steps(5);
  break;
 case ($cuantos <= 200):
 $x_labels->set_steps(12);
 $x_axis->set_steps(6); 
  break;
 case ($cuantos <= 260):
 $x_labels->set_steps(16);
 $x_axis->set_steps(8);
  break;
 case ($cuantos <= 300):
 $x_labels->set_steps(18);
 $x_axis->set_steps(9);
  break;
 case ($cuantos > 300):
 $x_labels->set_steps(30);
 $x_axis->set_steps(15);
  break;
}

// metemos linea en el grafico:
if ($cuantos != 0)
{
$chart->add_element( $linea_t1 );
$chart->add_element( $linea_t2 );
$chart->add_element( $linea_h1 );
}
//definimos eje y

$y_axis = new y_axis();
$y_axis->set_range( round($minimo) -5, round($maximo) +5, 10 );
$y_legend = new y_legend( 'Temperatura (&#xB0;C)                                                    Humedad (&#37;HR)' );
$y_legend->set_style( '{font-size: 15px; color: #000000}' );
$chart->set_y_legend( $y_legend );
$x_legend = new x_legend( 'Horas' );
$x_legend->set_style( '{font-size: 15px; color: #000000}' );
$chart->set_x_legend( $x_legend );

//incluimos ejes en el grafico
$chart->add_y_axis( $y_axis );
$chart->set_x_axis( $x_axis );

echo $chart->toPrettyString();

?>

﻿WeatherLAN - Hector Fiel


Este fichero contiene el código del proyecto WeatherLAN, disponible en http://weatherlan.hfiel.es


Descargue la documentación de la página del proyecto.



Contenido de las carpetas:

-codigo: código fuente del programa arduino, y librerias necesarias

-esquema eagle: esquema de circuitos electricos y placa PCB, editor eagle de CadSoft (http://www.cadsoftusa.com/). Incluye las reglas empleadas en el diseño de la placa.

-imagenes: imágenes de los esquemas y placa PCB

-licencias: textos de las licencias incluidas en el proyecto

-script bbdd: script SQL para la creación de las tablas. Script SQL con datos de ejemplo.

-web: ficheros del servidor web.
